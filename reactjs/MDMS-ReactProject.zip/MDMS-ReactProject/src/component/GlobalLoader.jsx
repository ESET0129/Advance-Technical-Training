import '../styles/Utility.css';

export default function GlobalLoader() {
  return (
    <div className="utility-page">
      <div className="utility-box">
        <h1>Loading...</h1>
      </div>
    </div>
  );
}

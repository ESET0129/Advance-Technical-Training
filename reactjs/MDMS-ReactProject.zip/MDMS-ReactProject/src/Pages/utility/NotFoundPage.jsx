import '../../styles/Utility.css';

export default function NotFoundPage() {
  return (
    <div className="utility-page">
      <div className="utility-box">
        <h1>404 NOT FOUND</h1>
      </div>
    </div>
  );
}
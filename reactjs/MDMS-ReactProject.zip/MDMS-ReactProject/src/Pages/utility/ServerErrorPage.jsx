import '../../styles/Utility.css';

export default function ServerErrorPage() {
  return (
    <div className="utility-page">
      <div className="utility-box">
        <h1>500 INTERNAL SERVER ERROR</h1>
      </div>
    </div>
  );
}
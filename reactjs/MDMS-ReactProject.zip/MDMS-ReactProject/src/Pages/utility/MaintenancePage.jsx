import '../../styles/Utility.css';

export default function MaintenancePage() {
  return (
    <div className="utility-page">
      <div className="utility-box">
        <h1>Maintenance Page</h1>
      </div>
    </div>
  );
}
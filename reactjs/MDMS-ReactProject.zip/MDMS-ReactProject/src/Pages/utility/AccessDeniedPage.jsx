import '../../styles/Utility.css';

export default function AccessDeniedPage() {
  return (
    <div className="utility-page">
      <div className="utility-box">
        <h1>Access Denied</h1>
      </div>
    </div>
  );
}